package com.cts.eauction.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.eauction.beans.UserDetails;
import com.cts.eauction.service.MyProfileService;
import com.cts.eauction.service.MyProfileServiceImpl;


@WebServlet("/MyProfileServlet")
public class MyProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    MyProfileService daoprofile=new MyProfileServiceImpl();

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession ss = request.getSession(); 
		String user_id = (String) ss.getAttribute("UserId");
		UserDetails user=daoprofile.UpdateUser(user_id);
		 response.setContentType("text/html");
		
		
		 System.out.println("My prof:"+user_id);
		 request.setAttribute("userId",user.getUserId());
		 request.setAttribute("firstName",user.getFirstName());
		 request.setAttribute("lastName", user.getLastName());
		 request.setAttribute("password", user.getPassword());
		 request.setAttribute("reEnterPassword",user.getReEnterPassword());
		 request.setAttribute("building" ,user.getBuildingNumberAndStreet());
		 request.setAttribute("city" ,user.getCity());
		 request.setAttribute("state", user.getState());
		 request.setAttribute("pin", user.getPin());
		 request.setAttribute("phone",user.getPhone());
		 request.setAttribute("email",user.getEmail());
		 request.setAttribute("paypalAccount",user.getPaypalAccount());
	     RequestDispatcher rd=request.getRequestDispatcher("myprofile.jsp");
	     rd.include(request, response);
		
	}

}
