package com.cts.eauction.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.eauction.beans.UserDetails;
import com.cts.eauction.service.RegisterService;
import com.cts.eauction.service.RegisterServiceImpl;


@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	 RegisterService regser=new RegisterServiceImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html"); 
		PrintWriter  pw = response.getWriter();
		 String userId=request.getParameter("user_id");
	     String firstName= request.getParameter("first_name");
	     String lastName= request.getParameter("last_name");
	     String password= request.getParameter("password");
	     String reEnterPassword= request.getParameter("reenter_password");
	     String buildingNumberAndStreet= request.getParameter("building");
	     
	     String city= request.getParameter("city");
	     String state= request.getParameter("state");
	     int pin= Integer.parseInt(request.getParameter("pin"));
	     String phone= request.getParameter("phone");
	     System.out.println("p"+phone);
	     String email= request.getParameter("email");
	     int paypalAccount= Integer.parseInt(request.getParameter("paypal_account"));
	     UserDetails user=new UserDetails();
	     user.setUserId(userId);
	     user.setFirstName(firstName);
	     user.setLastName(lastName);
	     user.setPassword(password);
	     user.setReEnterPassword(reEnterPassword);
	     user.setBuildingNumberAndStreet(buildingNumberAndStreet);
	     user.setCity(city);
	     user.setState(state);
	     user.setPin(pin);
	     user.setPhone(phone);
	     user.setEmail(email);
	     user.setPaypalAccount(paypalAccount);
	     boolean res=regser.registerservice(user);
	     if(res)
		{
			RequestDispatcher rd1 = request.getRequestDispatcher("index.jsp");
			pw.println("<script type=\"text/javascript\">");
			pw.println("alert('User Registered sucessfully');");
			pw.println("</script>");
			rd1.include(request, response);
		}
		else
		{
				pw.println("error");
		}	
			
	}

}
