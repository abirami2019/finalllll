package com.cts.eauction.service;

import com.cts.eauction.beans.UserDetails;

public interface RegisterService {
	public boolean registerservice(UserDetails user);

}
