package com.cts.eauction.service;

import java.util.List;

import com.cts.eauction.beans.Display;
import com.cts.eauction.dao.DisplayDao;
import com.cts.eauction.dao.DisplayDaoImpl;


public class DispalyServiceImpl implements DisplayService{
	DisplayDao dao = new DisplayDaoImpl();

	public List<Display> getProductDetails(Display sp) {
		List<Display> disp=dao.getProductDetails(sp);
		
		return disp;
	}
}
