package com.cts.eauction.service;

import java.util.List;

import com.cts.eauction.beans.BidProduct;



public interface BidService {
	
	public boolean Update(BidProduct bp);
	List<BidProduct> getBidDetails(BidProduct bp);  

}
