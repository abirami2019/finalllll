package com.cts.eauction.service;

import java.util.List;

import com.cts.eauction.beans.Purchase;

public interface MyPurchaseService {

	public List<Purchase> purchase(Purchase p);
}
