package com.cts.eauction.service;

import com.cts.eauction.dao.LoginDao;
import com.cts.eauction.dao.LoginDaoImpl;



public class LoginServiceImpl implements LoginService {

	String UserId;
	String Password;
	LoginDao logdao=new LoginDaoImpl();
	@Override
	public boolean loginservice(String user_id,String password) {
		
		UserId=user_id;
		Password=password;
		boolean result=logdao.validateUser(UserId,Password);
		return result;
	}

}
