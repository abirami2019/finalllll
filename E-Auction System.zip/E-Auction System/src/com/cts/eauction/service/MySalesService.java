package com.cts.eauction.service;

import java.util.List;

import com.cts.eauction.beans.Customer;
import com.cts.eauction.beans.Customer_Disp;

public interface MySalesService {

	public List<Customer_Disp> Disp(Customer c);
}
