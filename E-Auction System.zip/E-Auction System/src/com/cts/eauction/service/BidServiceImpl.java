package com.cts.eauction.service;

import java.util.List;

import com.cts.eauction.beans.BidProduct;
import com.cts.eauction.dao.BidDao;
import com.cts.eauction.dao.BidDaoImpl;


public class BidServiceImpl implements BidService {

	BidDao dao= new BidDaoImpl();
	public boolean Update(BidProduct bp) {
		
		boolean res=dao.Update(bp);
		return res;
	}
	@Override
	public List<BidProduct> getBidDetails(BidProduct bp) {
		List<BidProduct> bps=dao.getBidDetails(bp);
		return bps;
	}
}
