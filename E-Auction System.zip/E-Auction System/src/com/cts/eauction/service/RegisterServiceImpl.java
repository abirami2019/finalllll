package com.cts.eauction.service;

import com.cts.eauction.beans.UserDetails;
import com.cts.eauction.dao.RegisterDao;
import com.cts.eauction.dao.RegisterDaoImpl;

public class RegisterServiceImpl implements RegisterService {
	RegisterDao dao=new RegisterDaoImpl();
	@Override
	public boolean registerservice(UserDetails user) {
		dao.createDatabase();
		dao.createTableUserDetails();
		boolean res=dao.registerCheck(user);
		return res;
	}

}
