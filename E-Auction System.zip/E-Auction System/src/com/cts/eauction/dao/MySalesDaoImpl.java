package com.cts.eauction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cts.eauction.beans.Customer;
import com.cts.eauction.beans.Customer_Disp;
import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;
public class MySalesDaoImpl implements MySalesDao {

	@Override
	public List<Customer_Disp> SalesDisp(Customer c) {
		
        Connection conn = null;
        PreparedStatement pst = null;
        List<Customer_Disp> cus = new ArrayList<Customer_Disp>();
        System.out.println("vgfyegfy");
        try {
        	 System.out.println("vgfyegfy");
                        conn = DbUtil.getConnection(DbConstants.DRIVER , DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
                        if(conn != null)
                        {
                                        pst = conn.prepareStatement("select Product_Name,Short_Desc from put_for_sales where User_ID=? and status=?");
                                        pst.setString(1, c.getUserId());
                                        pst.setString(2, "SOLD");
                                        ResultSet res =  pst.executeQuery();
                                        while(res.next())
                                        {
                                        		
                                        				System.out.println(res.getString(1)+"\n"+ res.getString(2));
                                                        cus.add(new Customer_Disp(res.getString(1),res.getString(2)));
                                        }
                                        res.close();
                                        conn.close();
                                        
                                        
                        }
                        else
                                        System.out.println("not connected");
        } catch (Exception e) {
                        e.printStackTrace();
        }
        return cus;

	}

}
