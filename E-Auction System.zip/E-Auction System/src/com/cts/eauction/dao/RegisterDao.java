package com.cts.eauction.dao;

import com.cts.eauction.beans.UserDetails;

public interface RegisterDao {
	
	public void createDatabase();
	
	public void createTableUserDetails();
	
	public boolean registerCheck(UserDetails user);

}
