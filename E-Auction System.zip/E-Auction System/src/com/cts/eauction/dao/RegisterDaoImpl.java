package com.cts.eauction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cts.eauction.beans.UserDetails;
import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;

public class RegisterDaoImpl implements RegisterDao {
	
	Connection con=null;
	PreparedStatement pst=null;
	@Override
	public void createDatabase() {
		
		try {
			con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
			pst=con.prepareStatement("create database if not exists e_auction;");
			pst.executeUpdate();
			System.out.println("db created");
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	@Override
	public void createTableUserDetails() {
		
		try {
			
			con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
			pst=con.prepareStatement("create table if not exists user_details(user_id varchar(30) primary key not null,first_name varchar(30) not null,last_name varchar(30) not null,password varchar(30) not null,building_number_and_street varchar(30) not null,city varchar(20) not null,state varchar(20) not null,pin int(10) not null,phone int(11) not null,email varchar(30) not null,paypal_account int(15) not null);");
			pst.executeUpdate();
			System.out.println("table created");
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	
	@Override
	public boolean registerCheck(UserDetails user) {
		
			boolean b=false;
			try {
				con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
				pst=con.prepareStatement("insert into user_details(user_id,first_name,last_name,password,building_number_and_street,city,state,pin,phone,email,paypal_account) values(?,?,?,?,?,?,?,?,?,?,?)");
				pst.setString(1, user.getUserId());
				pst.setString(2, user.getFirstName());
				pst.setString(3,user.getLastName());
				pst.setString(4,user.getPassword());
				pst.setString(5,user.getBuildingNumberAndStreet());
				pst.setString(6,user.getCity());
				pst.setString(7,user.getState());
				pst.setInt(8,user.getPin());
				pst.setString(9,user.getPhone());
				pst.setString(10,user.getEmail());
				pst.setInt(11,user.getPaypalAccount());
				int r=pst.executeUpdate();
				//System.out.println("Logindao"+r);
				if(r>0)
					b=true;
				else
					b=false;
				con.close();
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			return b;
		}

	
	

}
