package com.cts.eauction.dao;

import com.cts.eauction.beans.Customer;

public interface CustomerDao {
	
	
	public void createTableSales();
	public void createTableBidding();
	public void createTablePurchase();
	public Boolean Insert(Customer c);
}
