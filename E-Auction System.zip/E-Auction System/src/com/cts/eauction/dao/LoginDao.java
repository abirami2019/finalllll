package com.cts.eauction.dao;



public interface LoginDao {
	
	public boolean validateUser(String user_id,String password);
	
}
