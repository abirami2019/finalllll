package com.cts.eauction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cts.eauction.beans.UserDetails;
import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;

public class UpdateUserDaoImpl implements UpdateUserDao {

	Connection con=null;
	PreparedStatement pst=null;
	
	@Override
	public boolean updateDao(UserDetails user) {
		boolean res=false;
		
		try {
			con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
			pst=con.prepareStatement("update user_details set user_id=?,first_name=?,last_name=?,password=?,building_number_and_street=?,city=?,state=?,pin=?,phone=?,email=?,paypal_account=? where User_id=?");
			pst.setString(1, user.getUserId());
			pst.setString(2, user.getFirstName());
			pst.setString(3,user.getLastName());
			pst.setString(4,user.getPassword());
			pst.setString(5,user.getBuildingNumberAndStreet());
			pst.setString(6,user.getCity());
			pst.setString(7,user.getState());
			pst.setInt(8,user.getPin());
			pst.setString (9,user.getPhone());
			pst.setString(10,user.getEmail());
			pst.setInt(11,user.getPaypalAccount());
			pst.setString(12, user.getUserId());
			int r=pst.executeUpdate();
			//System.out.println("Logindao"+r);
			if(r>0)
				res=true;
			else
				res=false;
			con.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
		return res;
	}

}
