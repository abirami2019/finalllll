package com.cts.eauction.dao;

import java.util.List;

import com.cts.eauction.beans.Display;



public interface DisplayDao {
	
	public List<Display> getProductDetails(Display sp);
}
