package com.cts.eauction.beans;



public class Display {
	
		String pid;
		int start_price;
		String pname;
		String detailDesc;
		public Display(int start_price, String pname,
				String detailDesc) {
			super();
			this.start_price = start_price;
			this.pname = pname;
			this.detailDesc = detailDesc;
		}
		
		
		public Display(String pid) {
			super();
			this.pid = pid;
		}


		public String getPid() {
			return pid;
		}
		public void setPid(String pid) {
			this.pid = pid;
		}
		public int getStart_price() {
			return start_price;
		}
		public void setStart_price(int start_price) {
			this.start_price = start_price;
		}
		public String getPname() {
			return pname;
		}
		public void setPname(String pname) {
			this.pname = pname;
		}
		public String getDetailDesc() {
			return detailDesc;
		}
		public void setDetailDesc(String detailDesc) {
			this.detailDesc = detailDesc;
		}
		


}
