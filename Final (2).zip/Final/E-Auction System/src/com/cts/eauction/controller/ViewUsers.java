package com.cts.eauction.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.eauction.beans.UserDetails;
import com.cts.eauction.service.ViewUserService;
import com.cts.eauction.service.ViewUserServiceImpl;




@WebServlet("/ViewUsers")
public class ViewUsers extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ViewUserService serv = new ViewUserServiceImpl();
	UserDetails user = new UserDetails();
	List<UserDetails> cd = new ArrayList<UserDetails>();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   response.setContentType("text/html");
	        //PrintWriter pw = response.getWriter();
	        HttpSession ss = request.getSession(); 
			String user_id = (String) ss.getAttribute("UserId");
			user.setUserId(user_id);
	        cd = serv.ViewUser(user);
	        request.setAttribute("ViewUser", cd);
	        System.out.println("outside");
	        RequestDispatcher rd = request.getRequestDispatcher("ViewUsers.jsp");
	        rd.forward(request, response);	
		
	}
}
