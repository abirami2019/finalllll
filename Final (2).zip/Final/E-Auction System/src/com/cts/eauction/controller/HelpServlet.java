package com.cts.eauction.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.eauction.beans.Help;
import com.cts.eauction.service.HelpService;
import com.cts.eauction.service.HelpServiceImpl;

@WebServlet("/HelpServlet")
public class HelpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   HelpService hser=new HelpServiceImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html"); 
		PrintWriter  pw = response.getWriter();
		String userId=request.getParameter("user_id");
	     String userName= request.getParameter("first_name");
	     String email= request.getParameter("email");
	     String phone= request.getParameter("phone");
	     String report= request.getParameter("report");
	     
	     Help help=new Help();
	     
	     help.setUserId(userId);
	     help.setUserName(userName);
	     help.setEmail(email);
	     help.setPhoneNumber(phone);
	     help.setReport(report);
	     
	     boolean res=hser.helpuser(help);
	     if(res)
		{
			RequestDispatcher rd1 = request.getRequestDispatcher("Home.jsp");
			pw.println("<script type=\"text/javascript\">");
			pw.println("alert('Your Feedback Has Been Taken');");
			pw.println("</script>");
			rd1.include(request, response);
		}
		else
		{
				pw.println("error");
		}	
	     
	}

	
}
