package com.cts.eauction.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.eauction.beans.UserDetails;
import com.cts.eauction.service.UpdateUserService;
import com.cts.eauction.service.UpdateUserServiceImpl;


@WebServlet("/UpdateUserServlet")
public class UpdateUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	UpdateUserService updser=new UpdateUserServiceImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		String userId=request.getParameter("user_id");
	     String firstName= request.getParameter("first_name");
	     String lastName= request.getParameter("last_name");
	     String password= request.getParameter("password");
	     String reEnterPassword= request.getParameter("reenter_password");
	     String building= request.getParameter("building");
	     String city= request.getParameter("city");
	     String state= request.getParameter("state");
	     int pin= Integer.parseInt(request.getParameter("pin"));
	     String phone=request.getParameter("phone");
	     String email= request.getParameter("email");
	     int paypalAccount= Integer.parseInt(request.getParameter("paypal_account"));
	     UserDetails user=new UserDetails();
	     user.setUserId(userId);
	     user.setFirstName(firstName);
	     user.setLastName(lastName);
	     user.setPassword(password);
	     user.setReEnterPassword(reEnterPassword);
	     user.setBuildingNumberAndStreet(building);
	     user.setCity(city);
	     user.setState(state);
	     user.setPin(pin);
	     user.setPhone(phone);
	     user.setEmail(email);
	     user.setPaypalAccount(paypalAccount);
	     
	     boolean res=updser.updateService(user);
	     //System.out.println("Result"+res);
	     RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
		 rd.forward(request, response);
	}

}
