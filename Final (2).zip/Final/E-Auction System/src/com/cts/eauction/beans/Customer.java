package com.cts.eauction.beans;



public class Customer {
	
	 private String UserId,ProductId;
	 private String PdtName,ShortDesc,DetDesc,Category;
	 private int Price,Days;
	 private String Bid_End_date,Status;
	 public Customer()
	 {
		 
	 }

	public Customer(String userId, String pdtName, String category, int price,
			String bid_End_date) {
		super();
		UserId = userId;
		PdtName = pdtName;
		Category = category;
		Price = price;
		Bid_End_date = bid_End_date;
	}

	public Customer(String userId, String productId, String pdtName,
			String shortDesc, String detDesc, String category, int price,
		 String bid_End_date, String status) {
		super();
		UserId = userId;
		ProductId = productId;
		PdtName = pdtName;
		ShortDesc = shortDesc;
		DetDesc = detDesc;
		Category = category;
		Price = price;
		Bid_End_date = bid_End_date;
		Status = status;
	}
	public Customer(int days) {
		super();
		Days = days;
	}

	public int getDays() {
		return Days;
	}

	public void setDays(int days) {
		Days = days;
	}

	public String getProductId() {
		return ProductId;
	}
	public void setProductId(String productId) {
		ProductId = productId;
	}
	public String getUserId() {
		return UserId;
	}
	public void setUserId(String userId) {
		UserId = userId;
	}
	public String getPdtName() {
		return PdtName;
	}
	public void setPdtName(String pdtName) {
		PdtName = pdtName;
	}
	public String getShortDesc() {
		return ShortDesc;
	}
	public void setShortDesc(String shortDesc) {
		ShortDesc = shortDesc;
	}
	public String getDetDesc() {
		return DetDesc;
	}
	public void setDetDesc(String detDesc) {
		DetDesc = detDesc;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	public String getBid_End_date() {
		return Bid_End_date;
	}
	public void setBid_End_date(String bid_End_date) {
		Bid_End_date = bid_End_date;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	
	
	
	
	 
	 
	 
	 
	
	 
	 
	
	 
	 

}
