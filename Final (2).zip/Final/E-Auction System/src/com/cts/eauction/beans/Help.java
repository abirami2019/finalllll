package com.cts.eauction.beans;

public class Help {
	private String UserId;
	 private String UserName,Email,PhoneNumber,Report;
	 
	 public Help()
	 {
		 
	 }
	 
	public Help(String userId, String userName, String email,
			String phoneNumber, String report) {
		super();
		UserId = userId;
		UserName = userName;
		Email = email;
		PhoneNumber = phoneNumber;
		Report = report;
	}
	public String getUserId() {
		return UserId;
	}
	public void setUserId(String userId) {
		UserId = userId;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public String getReport() {
		return Report;
	}
	public void setReport(String report) {
		Report = report;
	}
	 
}
