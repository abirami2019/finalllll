package com.cts.eauction.service;

import com.cts.eauction.beans.Help;


public interface HelpService {
	
	public boolean helpuser(Help help);

}
