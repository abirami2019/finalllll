package com.cts.eauction.service;

import com.cts.eauction.beans.UserDetails;

public interface UpdateUserService {

	public boolean updateService(UserDetails user);
}
