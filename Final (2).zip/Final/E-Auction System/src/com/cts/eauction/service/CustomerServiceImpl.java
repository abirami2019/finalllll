package com.cts.eauction.service;

import com.cts.eauction.beans.Customer;
import com.cts.eauction.dao.CustomerDao;
import com.cts.eauction.dao.CustomerDaoImpl;



public class CustomerServiceImpl implements CustomerService {

	CustomerDao dao = new CustomerDaoImpl();

	@Override
	public Boolean Insert(Customer c) {
		dao.createTableSales();
		dao.createTableBidding();
		dao.createTablePurchase();
		Boolean res = dao.Insert(c);
		
		return res;

}
}
