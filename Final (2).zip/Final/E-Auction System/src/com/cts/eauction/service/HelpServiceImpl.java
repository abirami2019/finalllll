package com.cts.eauction.service;

import com.cts.eauction.beans.Help;

import com.cts.eauction.dao.HelpDao;
import com.cts.eauction.dao.HelpDaoImpl;

public class HelpServiceImpl implements HelpService {

	HelpDao dao=new HelpDaoImpl();
	@Override
	public boolean helpuser(Help help) {
		
		dao.createTableHelp();
		boolean res=dao.helpUser(help);
		return res;
		
	}

}
