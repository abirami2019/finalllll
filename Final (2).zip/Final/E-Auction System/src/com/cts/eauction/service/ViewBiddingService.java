package com.cts.eauction.service;

import java.util.List;

import com.cts.eauction.beans.BidProduct;


public interface ViewBiddingService {
	public List<BidProduct> ViewBidding(BidProduct bp);
}
