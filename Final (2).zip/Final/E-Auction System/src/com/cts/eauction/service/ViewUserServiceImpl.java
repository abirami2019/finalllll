package com.cts.eauction.service;

import java.util.ArrayList;
import java.util.List;

import com.cts.eauction.beans.Customer;
import com.cts.eauction.beans.UserDetails;
import com.cts.eauction.dao.ViewProductDao;
import com.cts.eauction.dao.ViewProductDaoImpl;
import com.cts.eauction.dao.ViewUserDao;
import com.cts.eauction.dao.ViewUserDaoImpl;

public class ViewUserServiceImpl implements ViewUserService{
	ViewUserDao dao = new ViewUserDaoImpl();
	List<UserDetails> cd = new ArrayList<UserDetails>();
	@Override
	public List<UserDetails> ViewUser(UserDetails user) {
		cd = dao.ViewUser(user);
	    return cd;
	}

}
