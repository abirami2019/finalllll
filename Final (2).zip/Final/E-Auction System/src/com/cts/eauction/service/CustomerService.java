package com.cts.eauction.service;

import com.cts.eauction.beans.Customer;

public interface CustomerService {
	public Boolean Insert(Customer c);
}
