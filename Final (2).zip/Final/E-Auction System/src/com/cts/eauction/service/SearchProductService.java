package com.cts.eauction.service;

import java.util.List;

import com.cts.eauction.beans.SearchProduct;


public interface SearchProductService {
	
	public List<SearchProduct> getProductInfo(SearchProduct sp);
	public void updateSold(SearchProduct sp);


}
