package com.cts.eauction.service;



import org.apache.catalina.User;

import com.cts.eauction.beans.UserDetails;
import com.cts.eauction.dao.MyProfileDao;
import com.cts.eauction.dao.MyProfileDaoImpl;

public class MyProfileServiceImpl implements MyProfileService {

	MyProfileDao profiledao=new MyProfileDaoImpl();
	@Override
	public UserDetails UpdateUser(String user_id) {
		
		UserDetails user=profiledao.UpdateUserDetails(user_id);
		return user;
	}
	
	

}
