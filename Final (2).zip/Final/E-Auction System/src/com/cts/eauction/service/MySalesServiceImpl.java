package com.cts.eauction.service;

import java.util.ArrayList;
import java.util.List;

import com.cts.eauction.beans.Customer;
import com.cts.eauction.beans.Customer_Disp;
import com.cts.eauction.dao.MySalesDao;
import com.cts.eauction.dao.MySalesDaoImpl;


public class MySalesServiceImpl implements MySalesService {

	MySalesDao dao = new MySalesDaoImpl();
    List<Customer_Disp> cd = new ArrayList<Customer_Disp>();

	@Override
	public List<Customer_Disp> Disp(Customer c) {
		
        cd = dao.SalesDisp(c);
        return cd;

	}

	
}
