package com.cts.eauction.service;

import java.util.List;

import com.cts.eauction.beans.Customer;

public interface ViewProductService {
	
		public List<Customer> ViewProduct(Customer c);
}


