package com.cts.eauction.service;

import java.util.ArrayList;
import java.util.List;
import com.cts.eauction.beans.Customer;
import com.cts.eauction.dao.ViewProductDao;
import com.cts.eauction.dao.ViewProductDaoImpl;

public class ViewProductServiceImpl implements ViewProductService{
	ViewProductDao dao = new ViewProductDaoImpl();
    List<Customer> cd = new ArrayList<Customer>();
	@Override
	public List<Customer> ViewProduct(Customer c) {
			System.out.println("serimpl");
		cd = dao.ViewProduct(c);
        return cd;
	}

}
