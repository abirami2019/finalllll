package com.cts.eauction.dao;

import com.cts.eauction.beans.UserDetails;

public interface UpdateUserDao {
	
	public boolean updateDao(UserDetails user);
	

}
