package com.cts.eauction.dao;

import java.util.List;

import com.cts.eauction.beans.BidProduct;

public interface ViewBiddingDao {
	public List<BidProduct> ViewBidding(BidProduct bp);
}
