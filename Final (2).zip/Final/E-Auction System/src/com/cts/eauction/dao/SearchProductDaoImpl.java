package com.cts.eauction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cts.eauction.beans.SearchProduct;
import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;


public class SearchProductDaoImpl implements SearchProductDao {


	public List<SearchProduct> getProductInfo(SearchProduct sp) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs=null;
		int days=0;
		List<SearchProduct> search=new ArrayList<SearchProduct>();
		try {
			
			conn = DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME,DbConstants.PWD);
			pst = conn.prepareStatement("select * from put_for_sales where category=? and days!=0");
			pst.setString(1, sp.getCategory());
		
			rs= pst.executeQuery();
			SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
			String current=sf.format(new Date());
			while(rs.next())
			{
				String end=rs.getString(8);
				LocalDate startDate = LocalDate.parse(end); 
				LocalDate endDate = LocalDate.parse(current);
				Period period = Period.between(startDate, endDate); 
				days=period.getDays();
				search.add(new SearchProduct(rs.getString(2),rs.getString(3), rs.getString(4),days,rs.getInt(10)));
				
			}
			
			rs.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return search;
	}

	@Override
	public void updateSold(SearchProduct sp) {
		Connection conn = null;
		PreparedStatement pst = null;
		System.out.println("hrorhoro");
		try {
			System.out.println("hrorhoro");
			conn = DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME,DbConstants.PWD);
			pst=conn.prepareStatement("update put_for_sales set status='SOLD' where days=0");
			pst.executeUpdate();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	

}
