package com.cts.eauction.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;


import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cts.eauction.beans.BidProduct;
import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;



public class BidDaoImpl implements BidDao{
		
		@Override
		public boolean Update(BidProduct bp) {
			Connection con=null;
			PreparedStatement pst=null;
			boolean b=false;
			ResultSet rs=null;
			
			try {
				con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
				SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
				String date=sf.format(new Date());
		
				pst=con.prepareStatement("select product_id,last_bid_price,bid_end_date,days from put_for_sales where product_id=?");
			    pst.setString(1, bp.getProductId());
			    System.out.println(bp.getProductId());
				rs=pst.executeQuery();
				System.out.println("ajksdasdgjk");
				int bprice=bp.getBidPrice();
				System.out.println(bprice);
				while(rs.next()){
					System.out.println("amou1");
					int bidding_price=rs.getInt("last_bid_price"); 
					System.out.println(bidding_price);

					if(bprice > bidding_price)
						{
						System.out.println("amou");
						pst=con.prepareStatement("update bidding set bid=?,bidding_price=?,rdate=? where bidding_price<? and product_id=? ");
						pst.setString(1, bp.getBidId());
						pst.setInt(2, bp.getBidPrice() );
						pst.setString(3, date);
						
						//pst.setString(4, bp.getProductId());
						pst.setInt(4, bp.getBidPrice());
						pst.setString(5, bp.getProductId() );
						pst.executeUpdate();
						b=true;
						pst=con.prepareStatement("update put_for_sales set last_bid_price=? where product_id=? ");
						pst.setInt(1, bp.getBidPrice());
						pst.setString(2, bp.getProductId() );
						pst.executeUpdate();
						
						
					}
					else
					{
						b=false;
					}
					}
				con.close();
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			return b;
		}	

}
