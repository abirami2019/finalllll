package com.cts.eauction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;

public class LoginDaoImpl implements LoginDao {

	@Override
	public boolean validateUser(String user_id,String password) {
		
		Connection con=null;
		PreparedStatement pst=null;
		boolean result=false;
		
		try {
			con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
			if(user_id.equalsIgnoreCase("admin"))
			{	
				if(password.equalsIgnoreCase("123"))
				{
					result=true;
				}
				else
				{
					result=false;
				}
				con.close();
			}
			else
			{
				pst=con.prepareStatement("select user_id,password from User_details where user_id=? and password=?");
				pst.setString(1,user_id);
				pst.setString(2,password);
				ResultSet rs=pst.executeQuery();
				if(rs.next())
					result=true;
				else
					result=false;
				con.close();
			}
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		return result;
	}

}
