package com.cts.eauction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cts.eauction.beans.Customer;
import com.cts.eauction.beans.UserDetails;
import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;

public class ViewUserDaoImpl implements ViewUserDao {

	public List<UserDetails> ViewUser(UserDetails user) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs=null;
		List<UserDetails> viewuser=new ArrayList<UserDetails>();
		try {
			System.out.println("daoimpl");
			conn = DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME,DbConstants.PWD);
			pst = conn.prepareStatement("select * from user_details");
			rs= pst.executeQuery();		
			while(rs.next())
			{
				System.out.println("inside");
				viewuser.add(new UserDetails(rs.getString(1),rs.getString(2),rs.getString(6),rs.getString(9),rs.getString(10)));
			}
			rs.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	return viewuser;
	}

}
