package com.cts.eauction.dao;

import com.cts.eauction.beans.Help;


public interface HelpDao {
	public void createTableHelp();
	public boolean helpUser(Help help);
}
