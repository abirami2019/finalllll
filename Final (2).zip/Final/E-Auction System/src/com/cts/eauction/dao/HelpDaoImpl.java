package com.cts.eauction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cts.eauction.beans.Help;
import com.cts.eauction.beans.UserDetails;
import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;

public class HelpDaoImpl implements HelpDao {

	Connection con=null;
	PreparedStatement pst=null;
	@Override
	public void createTableHelp() {
		
try {
			
			con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
			pst=con.prepareStatement("create table if not exists help(user_id varchar(30)not null,first_name varchar(30) not null,phone varchar(11) not null,email varchar(30) not null,report varchar(30) not null);");
			pst.executeUpdate();
			System.out.println("table created");
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean helpUser(Help help) {
		boolean b=false;
		try {
			con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
			pst=con.prepareStatement("insert into help(user_id,first_name,phone,email,report) values(?,?,?,?,?)");
			pst.setString(1, help.getUserId());
			pst.setString(2, help.getUserName());
			pst.setString(3,help.getPhoneNumber());
			pst.setString(4,help.getEmail());
			pst.setString(5,help.getReport());
			int r=pst.executeUpdate();
			//System.out.println("Logindao"+r);
			if(r>0)
				b=true;
			else
				b=false;
			con.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		return b;
		
	}

}
