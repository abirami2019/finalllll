package com.cts.eauction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cts.eauction.beans.BidProduct;
import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;

public class ViewBiddingDaoImpl implements ViewBiddingDao {

	@Override
	public List<BidProduct> ViewBidding(BidProduct bp) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs=null;
		List<BidProduct> bps=new ArrayList<BidProduct>();
		try {
			con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
			ps=con.prepareStatement("select * from bidding where category=?");
			ps.setString(1, bp.getCategory());
			rs=ps.executeQuery();
			while(rs.next())
			{
				bps.add(new BidProduct( rs.getString(1),rs.getInt(2), rs.getString(3), rs.getString(4)));
				System.out.println(rs.getString(3));
				bp.setDate(rs.getString(3));
			}
		
			rs.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	return bps;
	}
	

}
